﻿namespace ScheduleSys.SystemSetting
{
    partial class Delayloading
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.comboBox_trainlist = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.textBox_delaytime = new System.Windows.Forms.TextBox();
            this.button_sure = new System.Windows.Forms.Button();
            this.button_cancel = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.comboBox_stationlist = new System.Windows.Forms.ComboBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label7 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.comboBox_section = new System.Windows.Forms.ComboBox();
            this.textBox_endtime = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.textBox_starttime = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(22, 63);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(71, 12);
            this.label1.TabIndex = 0;
            this.label1.Text = "Delay Train";
            // 
            // comboBox_trainlist
            // 
            this.comboBox_trainlist.FormattingEnabled = true;
            this.comboBox_trainlist.Location = new System.Drawing.Point(127, 60);
            this.comboBox_trainlist.Name = "comboBox_trainlist";
            this.comboBox_trainlist.Size = new System.Drawing.Size(121, 20);
            this.comboBox_trainlist.TabIndex = 1;
            this.comboBox_trainlist.SelectedIndexChanged += new System.EventHandler(this.combobox_delay_train_changed);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(22, 96);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(65, 12);
            this.label2.TabIndex = 2;
            this.label2.Text = "Delay time";
            // 
            // textBox_delaytime
            // 
            this.textBox_delaytime.Location = new System.Drawing.Point(127, 93);
            this.textBox_delaytime.Name = "textBox_delaytime";
            this.textBox_delaytime.Size = new System.Drawing.Size(121, 21);
            this.textBox_delaytime.TabIndex = 3;
            this.textBox_delaytime.VisibleChanged += new System.EventHandler(this.textbox_delaytime_valuechanged);
            // 
            // button_sure
            // 
            this.button_sure.Location = new System.Drawing.Point(80, 365);
            this.button_sure.Name = "button_sure";
            this.button_sure.Size = new System.Drawing.Size(75, 23);
            this.button_sure.TabIndex = 4;
            this.button_sure.Text = "Sure";
            this.button_sure.UseVisualStyleBackColor = true;
            this.button_sure.Click += new System.EventHandler(this.button_sure_Click);
            // 
            // button_cancel
            // 
            this.button_cancel.Location = new System.Drawing.Point(218, 365);
            this.button_cancel.Name = "button_cancel";
            this.button_cancel.Size = new System.Drawing.Size(75, 23);
            this.button_cancel.TabIndex = 4;
            this.button_cancel.Text = "Cancel";
            this.button_cancel.UseVisualStyleBackColor = true;
            this.button_cancel.Click += new System.EventHandler(this.button_cancel_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(22, 130);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(47, 12);
            this.label3.TabIndex = 5;
            this.label3.Text = "Station";
            // 
            // comboBox_stationlist
            // 
            this.comboBox_stationlist.FormattingEnabled = true;
            this.comboBox_stationlist.Location = new System.Drawing.Point(127, 130);
            this.comboBox_stationlist.Name = "comboBox_stationlist";
            this.comboBox_stationlist.Size = new System.Drawing.Size(121, 20);
            this.comboBox_stationlist.TabIndex = 6;
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.comboBox_trainlist);
            this.panel1.Controls.Add(this.comboBox_stationlist);
            this.panel1.Controls.Add(this.label7);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.textBox_delaytime);
            this.panel1.Location = new System.Drawing.Point(32, 66);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(261, 205);
            this.panel1.TabIndex = 7;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(22, 24);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(35, 12);
            this.label7.TabIndex = 0;
            this.label7.Text = "Delay";
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.comboBox_section);
            this.panel2.Controls.Add(this.textBox_endtime);
            this.panel2.Controls.Add(this.label8);
            this.panel2.Controls.Add(this.textBox_starttime);
            this.panel2.Controls.Add(this.label6);
            this.panel2.Controls.Add(this.label5);
            this.panel2.Controls.Add(this.label4);
            this.panel2.Location = new System.Drawing.Point(317, 66);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(232, 205);
            this.panel2.TabIndex = 8;
            // 
            // comboBox_section
            // 
            this.comboBox_section.FormattingEnabled = true;
            this.comboBox_section.Location = new System.Drawing.Point(88, 60);
            this.comboBox_section.Name = "comboBox_section";
            this.comboBox_section.Size = new System.Drawing.Size(127, 20);
            this.comboBox_section.TabIndex = 1;
            this.comboBox_section.SelectedIndexChanged += new System.EventHandler(this.broken_section_select_index_changed);
            // 
            // textBox_endtime
            // 
            this.textBox_endtime.Location = new System.Drawing.Point(88, 130);
            this.textBox_endtime.Name = "textBox_endtime";
            this.textBox_endtime.Size = new System.Drawing.Size(127, 21);
            this.textBox_endtime.TabIndex = 9;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(15, 24);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(71, 12);
            this.label8.TabIndex = 0;
            this.label8.Text = "Disturbance";
            // 
            // textBox_starttime
            // 
            this.textBox_starttime.Location = new System.Drawing.Point(88, 96);
            this.textBox_starttime.Name = "textBox_starttime";
            this.textBox_starttime.Size = new System.Drawing.Size(127, 21);
            this.textBox_starttime.TabIndex = 9;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(3, 138);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(53, 12);
            this.label6.TabIndex = 0;
            this.label6.Text = "End Time";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(3, 99);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(65, 12);
            this.label5.TabIndex = 0;
            this.label5.Text = "Start Time";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(3, 63);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(47, 12);
            this.label4.TabIndex = 0;
            this.label4.Text = "Section";
            // 
            // Delayloading
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(610, 484);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.button_cancel);
            this.Controls.Add(this.button_sure);
            this.Name = "Delayloading";
            this.Text = "Delay loading";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox comboBox_trainlist;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox textBox_delaytime;
        private System.Windows.Forms.Button button_sure;
        private System.Windows.Forms.Button button_cancel;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ComboBox comboBox_stationlist;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.ComboBox comboBox_section;
        private System.Windows.Forms.TextBox textBox_endtime;
        private System.Windows.Forms.TextBox textBox_starttime;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
    }
}