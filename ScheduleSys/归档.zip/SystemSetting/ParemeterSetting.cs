﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ScheduleSys.SystemSetting
{ 
    public partial class ParemeterSetting : Form
    {
        //MainForm mainform;
        int departurearriveh_initial;//会车间隔的初始值
        int departurearrivel_initial;//连发间隔的初始值
        int departuredeparture_initial;//不同时离开的初始值
        int arrivearrive_initial;//不同时到达的初始值
        int accelerate_initial;
        int decelerate_initial;
        bool saveflag = true;
        //SettingKind settingfor;
        public ParemeterSetting()
        {
            InitializeComponent();
            //this.settingfor = _settingfor;
            //if(_settingfor==SettingKind.headway)
            //{
            //    
            //}
            //else if(_settingfor==SettingKind.slack)
            //{
            //    
            //}
            InitialValue_headway();
            Initial_slack();
        }

        //public ParemeterSetting():this()
        //{
        //    this.mainform = mainform;
        //    InitialValue();
        //}

        private void Paremeter_Setting_Savebtn_Click(object sender, EventArgs e)
        {
            if(saveflag==true)
            {
                return;
            }
            if(MessageBox.Show("Are you sure to save？","Message",MessageBoxButtons.YesNo,MessageBoxIcon.Exclamation)==DialogResult.Yes)
            {
                //if(settingfor==SettingKind.headway)
                //{
                    DataReadWrite.WriteIniData("Headway", "Departure_Arrive_H", departurearrivehnud.Value.ToString(), Application.StartupPath + "\\Paremeter.ini");
                    DataReadWrite.WriteIniData("Headway", "Departure_Arrive_L", departurearrivelnud.Value.ToString(), Application.StartupPath + "\\Paremeter.ini");
                    DataReadWrite.WriteIniData("Headway", "Departure_Departure", departuredeparturenud.Value.ToString(), Application.StartupPath + "\\Paremeter.ini");
                    DataReadWrite.WriteIniData("Headway", "Arrive_Arrive", arrivearrivenud.Value.ToString(), Application.StartupPath + "\\Paremeter.ini");
                    DataReadWrite.WriteIniData("Acelerate", "acelerate", numericUpDown_acelerate.Value.ToString(), Application.StartupPath + "\\Paremeter.ini");
                    DataReadWrite.WriteIniData("Acelerate", "decelerate", numericUpDown_decelerate.Value.ToString(), Application.StartupPath + "\\Paremeter.ini");
                //}
                //else
                //{
                    DataReadWrite.WriteIniData("Slack","arriveslack",textBox_arrive_slack.Text,Application.StartupPath + "\\Paremeter.ini");
                    DataReadWrite.WriteIniData("Slack", "departureslack", textBox_departure_slack.Text, Application.StartupPath + "\\Paremeter.ini");
                    DataReadWrite.WriteIniData("Slack", "slackornot", comboBox_yesno.Text, Application.StartupPath + "\\Paremeter.ini");
                //}
                saveflag = true;
            }
        }
        //初始化控件的值
        void InitialValue_headway()
        {
            departurearriveh_initial = int.Parse(DataReadWrite.ReadIniData("Headway", "Departure_Arrive_H","" ,Application.StartupPath + "\\Paremeter.ini"));
            departurearrivel_initial = int.Parse(DataReadWrite.ReadIniData("Headway", "Departure_Arrive_L", "", Application.StartupPath + "\\Paremeter.ini"));
            departuredeparture_initial = int.Parse(DataReadWrite.ReadIniData("Headway", "Departure_Departure", "", Application.StartupPath + "\\Paremeter.ini"));
            arrivearrive_initial = int.Parse(DataReadWrite.ReadIniData("Headway", "Arrive_Arrive", "", Application.StartupPath + "\\Paremeter.ini"));
            accelerate_initial=int.Parse(DataReadWrite.ReadIniData("Acelerate", "acelerate","", Application.StartupPath + "\\Paremeter.ini"));
            decelerate_initial=int.Parse(DataReadWrite.ReadIniData("Acelerate", "decelerate","", Application.StartupPath + "\\Paremeter.ini"));
            //设置控件的值
            departurearrivehnud.Value = departurearriveh_initial;
            departurearrivelnud.Value = departurearrivel_initial;
            departuredeparturenud.Value = departuredeparture_initial;
            arrivearrivenud.Value = arrivearrive_initial;
            numericUpDown_acelerate.Value = accelerate_initial;
            numericUpDown_decelerate.Value = decelerate_initial;

            //Tab_control.Enabled = false;
        }
        //设置tab
        void Initial_slack()
        {
            //panel_headway.Enabled = false;
            textBox_arrive_slack.Text = DataReadWrite.ReadIniData("Slack", "arriveslack", "", Application.StartupPath + "\\Paremeter.ini");
            textBox_departure_slack.Text = DataReadWrite.ReadIniData("Slack", "departureslack", "", Application.StartupPath + "\\Paremeter.ini");
            comboBox_yesno.Items.Add("true");
            comboBox_yesno.Items.Add("false");
            comboBox_yesno.SelectedIndexChanged -= yesno_selectindexchanged;
            comboBox_yesno.SelectedItem = DataReadWrite.ReadIniData("Slack", "slackornot", "", Application.StartupPath + "\\Paremeter.ini");
            comboBox_yesno.SelectedIndexChanged += yesno_selectindexchanged;
        }
        private void departurearrivehnud_valuechanged(object sender, EventArgs e)
        {
            saveflag = false;
        }

        private void departurearrivelnud_valuechanged(object sender, EventArgs e)
        {
            saveflag = false;
        }

        private void departuredeparturenud_valuechangd(object sender, EventArgs e)
        {
            saveflag = false;
        }
        private void arrivearrivenud_valuechangd(object sender, EventArgs e)
        {
            saveflag = false;
        }

        private void Paremeter_Setting_Cancelbtn_Click(object sender, EventArgs e)
        {
            if(saveflag==false)
            {
                Paremeter_Setting_Savebtn.PerformClick();
                this.Close();
            }
            else
            {
                this.Close();
            }
        }

        private void Paremeter_Setting_Surebtn_Click(object sender, EventArgs e)
        {
            if (saveflag == false)
            {
                Paremeter_Setting_Savebtn.PerformClick();
                this.Close();
            }
            else
            {
                this.Close();
            }
        }

        private void acelerate_changed(object sender, EventArgs e)
        {
            saveflag = false;

        }

        private void decelerate_changed(object sender, EventArgs e)
        {

            saveflag = false;
        }

        private void arrive_slack_textchanged(object sender, EventArgs e)
        {
            saveflag = false;
        }

        private void departure_slack_textchanged(object sender, EventArgs e)
        {
            saveflag = false;
        }

        private void yesno_selectindexchanged(object sender, EventArgs e)
        {
            saveflag = false;
        }
    }
    public enum SettingKind:int
    {
        headway=0,
        slack,
    }
}
