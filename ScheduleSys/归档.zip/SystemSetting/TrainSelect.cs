﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ScheduleSys.SystemSetting
{
    public partial class TrainSelect : Form
    {
        Graph g;
        bool saveflag;
        public TrainSelect()
        {
            InitializeComponent();
            
        }
        public TrainSelect(Graph g):this()
        {
            this.g = g;
            Initial();
            saveflag = true;
        }
        private void Initial()
        {
           foreach(Train train in g.trainlist)
           {
               checkedListBox_trainselect.Items.Add(train.name, train.trainselect);
           }
        }
        //保存按钮
        private void button_save_Click(object sender, EventArgs e)
        {
            if (saveflag == true)
            {
                return;
            }
            if (MessageBox.Show("Are you sure to save？", "Message", MessageBoxButtons.YesNo, MessageBoxIcon.Exclamation) == DialogResult.Yes)
            {
                foreach(Train train in g.trainlist)
                {
                    if(checkedListBox_trainselect.GetItemChecked(train.index)==true)
                    {
                        train.trainselect = true;
                    }
                    else
                    {
                        train.trainselect = false;
                    }
                }
                this.Close();
            }
            //saveflag = true;
        }
        //取消按钮
        private void button_cancel_Click(object sender, EventArgs e)
        {
            if (saveflag == false)
            {
                button_save.PerformClick();
                this.Close();
            }
            else
            {
                this.Close();
            }
        }
        //选中的列车发生变化
        private void checkedlistbox_select_index_changed(object sender, EventArgs e)
        {
            saveflag = false;
        }
    }
}
