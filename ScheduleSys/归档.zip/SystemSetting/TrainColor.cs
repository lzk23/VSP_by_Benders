﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ScheduleSys.SystemSetting
{
    public partial class TrainColor : Form
    {
        bool saveflag;
        string[] trainitem_key;
        bool havereadcolor;
        public TrainColor()
        {
            InitializeComponent();
            colorDialog_traincolor.AllowFullOpen = true;//用户可以自定义颜色
            colorDialog_traincolor.FullOpen = true;//指示用于创建自定义颜色的控件在对话框打开时可见
            colorDialog_traincolor.ShowHelp = true;
            ReadInitialColor();
            saveflag = true;
            havereadcolor = false;
        }
        //点击设置按钮
        private void button_settingcolor_Click(object sender, EventArgs e)
        {
            if(havereadcolor==false)
            {
                MessageBox.Show("Please click read color first.", "Message");
                return;
            }
            if(colorDialog_traincolor.ShowDialog()==DialogResult.OK)
            {
                //dataGridView_traincolor.CurrentRow.Cells["color"].Value = colorDialog_traincolor.Color.Name;
                dataGridView_traincolor.CurrentRow.Cells["color"].Style.BackColor = colorDialog_traincolor.Color;
                saveflag = false;
            }
        }
   
        //初始化设置的颜色
        //string c1 = System.Drawing.ColorTranslator.ToHtml(System.Drawing.Color.Red);
        //// c1 = "#ff0000";或c1 = "Red";

        //System.Drawing.Color c2 = System.Drawing.ColorTranslator.FromHtml("#ff0000");
        //string mm = listView1.Items[listView1.FocusedItem.Index].Text;
        //Color cl = Color.FromName(mm);
        private void ReadInitialColor()
        {
            trainitem_key = DataReadWrite.INIGetAllItemKeys(Application.StartupPath + "\\Paremeter.ini", "TrainColor"); 
            DataTable dt = new DataTable();
            dt.Columns.Add("train_name");
            dt.Columns.Add("color");
            foreach(string train_name in trainitem_key)
            {
                DataRow dr = dt.NewRow();
                dr["train_name"] = train_name;
                dr["color"] = "";
                dt.Rows.Add(dr);
            }
            //设置背景颜色
            //for (int row_index = 0; row_index < dt.Rows.Count - 1; row_index++)
            //{
            //    string train_name = dt.Rows[row_index].
            //    string colorrgb = DataReadWrite.ReadIniData("TrainColor", train_name, "", Application.StartupPath + "\\Paremeter.ini");
            //    Color color = ColorTranslator.FromHtml(colorrgb);
            //    dataGridView_traincolor.Rows[row_index].Cells["color"].Style.BackColor = ColorTranslator.FromHtml(colorrgb);
            //    //string color_name=DataReadWrite.ReadIniData("TrainColor",train_name,"",Application.StartupPath+"\\Paremeter.ini");
            //    //string colorrgb = DataReadWrite.ReadIniData("TrainColor", train_name, "", Application.StartupPath + "\\Paremeter.ini");
            //    //int red = 0, green = 0, blue = 0;
            //    //if(colorrgb!="0")
            //    //{
            //    //    string[] color = colorrgb.Split(',');
            //    //    red = int.Parse(color[0]);
            //    //    green = int.Parse(color[1]);
            //    //    blue = int.Parse(color[2]);
            //    //}
            //    //dataGridView_traincolor.Rows[row_index].Cells["color"].Style.BackColor = Color.FromArgb(red,green,blue);
            //}
            dataGridView_traincolor.DataSource = dt;
            //设置背景颜色
            
        }
        private void button_readcolor_Click(object sender, EventArgs e)
        {
            for (int row_index = 0; row_index < dataGridView_traincolor.Rows.Count - 1; row_index++)
            {
                string train_name = dataGridView_traincolor.Rows[row_index].Cells["train_name"].Value.ToString();
                string colorrgb = DataReadWrite.ReadIniData("TrainColor", train_name, "", Application.StartupPath + "\\Paremeter.ini");
                Color color = ColorTranslator.FromHtml(colorrgb);
                dataGridView_traincolor.Rows[row_index].Cells["color"].Style.BackColor = color;
            }
            havereadcolor = true;
        }
        //保存按钮
        private void button_save_Click(object sender, EventArgs e)
        {
            if(saveflag==true)
            {
                return;
            }
            else
            {
                if(MessageBox.Show("Are you sure to save.","Message",MessageBoxButtons.YesNo,MessageBoxIcon.Exclamation)==DialogResult.Yes)
                {
                    //foreach (string train_name in trainitem_key)
                    //{
                        //error here
                        //for(int row_index=0;row_index<dataGridView_traincolor.Rows.Count-1;row_index++)
                        //{
                        //    //name的方法无法保存
                        //    //string colorname = dataGridView_traincolor.Rows[row_index].Cells["color"].Style.BackColor.Name;
                        //    //DataReadWrite.WriteIniData("TrainColor", train_name, colorname, Application.StartupPath + "\\Paremeter.ini");
                        //    //这样也不行
                        //    string colorrgb = "#" + (dataGridView_traincolor.Rows[row_index].Cells["color"].Style.BackColor.ToArgb() & ~0xff000000).ToString("X2");
                        //    //string colorrgb = ColorTranslator.ToHtml(dataGridView_traincolor.Rows[row_index].Cells["color"].Style.BackColor);
                        //    DataReadWrite.WriteIniData("TrainColor", train_name, colorrgb, Application.StartupPath + "\\Paremeter.ini");
                        //    //int colorr = dataGridView_traincolor.Rows[row_index].Cells["color"].Style.BackColor.R;
                        //    //int colorg = dataGridView_traincolor.Rows[row_index].Cells["color"].Style.BackColor.G;
                        //    //int colorb = dataGridView_traincolor.Rows[row_index].Cells["color"].Style.BackColor.B;
                        //    //string rgb = colorr + "," + colorg + "," + colorb;
                        //    //DataReadWrite.WriteIniData("TrainColor", train_name, rgb, Application.StartupPath + "\\Paremeter.ini");
                        //}
                    //}
                    //末尾一行会选中，count need to differ 1
                        for(int row_index=0;row_index<dataGridView_traincolor.Rows.Count-1;row_index++)
                        {
                            string train_name = dataGridView_traincolor.Rows[row_index].Cells["train_name"].Value.ToString();
                            string colorrgb = ColorTranslator.ToHtml(dataGridView_traincolor.Rows[row_index].Cells["color"].Style.BackColor);
                            DataReadWrite.WriteIniData("TrainColor", train_name, colorrgb, Application.StartupPath + "\\Paremeter.ini");
                        }
                }
                saveflag = true;
            }
        }


    }
}
