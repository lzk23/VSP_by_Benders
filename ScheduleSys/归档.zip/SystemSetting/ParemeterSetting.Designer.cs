﻿namespace ScheduleSys.SystemSetting
{
    partial class ParemeterSetting
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label8 = new System.Windows.Forms.Label();
            this.Paremeter_Setting_Savebtn = new System.Windows.Forms.Button();
            this.Paremeter_Setting_Exitbtn = new System.Windows.Forms.Button();
            this.arrivearrivenud = new System.Windows.Forms.NumericUpDown();
            this.departuredeparturenud = new System.Windows.Forms.NumericUpDown();
            this.DoubleTracklbl = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.departurearrivehnud = new System.Windows.Forms.NumericUpDown();
            this.label5 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.SingleTracklbl = new System.Windows.Forms.Label();
            this.Paremeter_Setting_Surebtn = new System.Windows.Forms.Button();
            this.panel_headway = new System.Windows.Forms.Panel();
            this.numericUpDown_decelerate = new System.Windows.Forms.NumericUpDown();
            this.numericUpDown_acelerate = new System.Windows.Forms.NumericUpDown();
            this.departurearrivelnud = new System.Windows.Forms.NumericUpDown();
            this.label4 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.Cancelbtn = new System.Windows.Forms.Button();
            this.Tab_control = new System.Windows.Forms.TabControl();
            this.tabPage_slack = new System.Windows.Forms.TabPage();
            this.comboBox_yesno = new System.Windows.Forms.ComboBox();
            this.textBox_departure_slack = new System.Windows.Forms.TextBox();
            this.textBox_arrive_slack = new System.Windows.Forms.TextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            ((System.ComponentModel.ISupportInitialize)(this.arrivearrivenud)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.departuredeparturenud)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.departurearrivehnud)).BeginInit();
            this.panel_headway.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown_decelerate)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown_acelerate)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.departurearrivelnud)).BeginInit();
            this.Tab_control.SuspendLayout();
            this.tabPage_slack.SuspendLayout();
            this.SuspendLayout();
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(3, 327);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(83, 12);
            this.label8.TabIndex = 1;
            this.label8.Text = "Arrive-Arrive";
            // 
            // Paremeter_Setting_Savebtn
            // 
            this.Paremeter_Setting_Savebtn.Location = new System.Drawing.Point(472, 402);
            this.Paremeter_Setting_Savebtn.Name = "Paremeter_Setting_Savebtn";
            this.Paremeter_Setting_Savebtn.Size = new System.Drawing.Size(75, 23);
            this.Paremeter_Setting_Savebtn.TabIndex = 4;
            this.Paremeter_Setting_Savebtn.Text = "Save";
            this.Paremeter_Setting_Savebtn.UseVisualStyleBackColor = true;
            this.Paremeter_Setting_Savebtn.Click += new System.EventHandler(this.Paremeter_Setting_Savebtn_Click);
            // 
            // Paremeter_Setting_Exitbtn
            // 
            this.Paremeter_Setting_Exitbtn.Location = new System.Drawing.Point(371, 402);
            this.Paremeter_Setting_Exitbtn.Name = "Paremeter_Setting_Exitbtn";
            this.Paremeter_Setting_Exitbtn.Size = new System.Drawing.Size(75, 23);
            this.Paremeter_Setting_Exitbtn.TabIndex = 5;
            this.Paremeter_Setting_Exitbtn.Text = "Exit";
            this.Paremeter_Setting_Exitbtn.UseVisualStyleBackColor = true;
            // 
            // arrivearrivenud
            // 
            this.arrivearrivenud.Location = new System.Drawing.Point(132, 325);
            this.arrivearrivenud.Name = "arrivearrivenud";
            this.arrivearrivenud.Size = new System.Drawing.Size(120, 21);
            this.arrivearrivenud.TabIndex = 3;
            this.arrivearrivenud.ValueChanged += new System.EventHandler(this.arrivearrivenud_valuechangd);
            // 
            // departuredeparturenud
            // 
            this.departuredeparturenud.Location = new System.Drawing.Point(132, 284);
            this.departuredeparturenud.Name = "departuredeparturenud";
            this.departuredeparturenud.Size = new System.Drawing.Size(120, 21);
            this.departuredeparturenud.TabIndex = 3;
            this.departuredeparturenud.ValueChanged += new System.EventHandler(this.departuredeparturenud_valuechangd);
            // 
            // DoubleTracklbl
            // 
            this.DoubleTracklbl.AutoSize = true;
            this.DoubleTracklbl.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.DoubleTracklbl.Location = new System.Drawing.Point(29, 241);
            this.DoubleTracklbl.Name = "DoubleTracklbl";
            this.DoubleTracklbl.Size = new System.Drawing.Size(104, 16);
            this.DoubleTracklbl.TabIndex = 2;
            this.DoubleTracklbl.Text = "Double Track";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(30, 315);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(0, 12);
            this.label9.TabIndex = 1;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(65, 271);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(0, 12);
            this.label3.TabIndex = 1;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(70, 274);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(0, 12);
            this.label6.TabIndex = 1;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(3, 286);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(119, 12);
            this.label7.TabIndex = 1;
            this.label7.Text = "Departure-Departure";
            // 
            // departurearrivehnud
            // 
            this.departurearrivehnud.Location = new System.Drawing.Point(134, 67);
            this.departurearrivehnud.Name = "departurearrivehnud";
            this.departurearrivehnud.Size = new System.Drawing.Size(120, 21);
            this.departurearrivehnud.TabIndex = 3;
            this.departurearrivehnud.ValueChanged += new System.EventHandler(this.departurearrivehnud_valuechanged);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(3, 110);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(113, 12);
            this.label5.TabIndex = 1;
            this.label5.Text = "Departure-Arrive-L";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(3, 69);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(113, 12);
            this.label2.TabIndex = 1;
            this.label2.Text = "Departure-Arrive-H";
            // 
            // SingleTracklbl
            // 
            this.SingleTracklbl.AutoSize = true;
            this.SingleTracklbl.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.SingleTracklbl.Location = new System.Drawing.Point(29, 35);
            this.SingleTracklbl.Name = "SingleTracklbl";
            this.SingleTracklbl.Size = new System.Drawing.Size(104, 16);
            this.SingleTracklbl.TabIndex = 2;
            this.SingleTracklbl.Text = "Single Track";
            // 
            // Paremeter_Setting_Surebtn
            // 
            this.Paremeter_Setting_Surebtn.Location = new System.Drawing.Point(371, 446);
            this.Paremeter_Setting_Surebtn.Name = "Paremeter_Setting_Surebtn";
            this.Paremeter_Setting_Surebtn.Size = new System.Drawing.Size(75, 23);
            this.Paremeter_Setting_Surebtn.TabIndex = 6;
            this.Paremeter_Setting_Surebtn.Text = "Sure";
            this.Paremeter_Setting_Surebtn.UseVisualStyleBackColor = true;
            this.Paremeter_Setting_Surebtn.Click += new System.EventHandler(this.Paremeter_Setting_Surebtn_Click);
            // 
            // panel_headway
            // 
            this.panel_headway.Controls.Add(this.arrivearrivenud);
            this.panel_headway.Controls.Add(this.numericUpDown_decelerate);
            this.panel_headway.Controls.Add(this.departuredeparturenud);
            this.panel_headway.Controls.Add(this.numericUpDown_acelerate);
            this.panel_headway.Controls.Add(this.label9);
            this.panel_headway.Controls.Add(this.DoubleTracklbl);
            this.panel_headway.Controls.Add(this.label3);
            this.panel_headway.Controls.Add(this.departurearrivelnud);
            this.panel_headway.Controls.Add(this.label8);
            this.panel_headway.Controls.Add(this.departurearrivehnud);
            this.panel_headway.Controls.Add(this.label6);
            this.panel_headway.Controls.Add(this.label4);
            this.panel_headway.Controls.Add(this.label7);
            this.panel_headway.Controls.Add(this.label5);
            this.panel_headway.Controls.Add(this.label11);
            this.panel_headway.Controls.Add(this.label10);
            this.panel_headway.Controls.Add(this.label2);
            this.panel_headway.Controls.Add(this.SingleTracklbl);
            this.panel_headway.Controls.Add(this.label1);
            this.panel_headway.Location = new System.Drawing.Point(35, 38);
            this.panel_headway.Name = "panel_headway";
            this.panel_headway.Size = new System.Drawing.Size(257, 431);
            this.panel_headway.TabIndex = 3;
            // 
            // numericUpDown_decelerate
            // 
            this.numericUpDown_decelerate.Location = new System.Drawing.Point(134, 201);
            this.numericUpDown_decelerate.Name = "numericUpDown_decelerate";
            this.numericUpDown_decelerate.Size = new System.Drawing.Size(120, 21);
            this.numericUpDown_decelerate.TabIndex = 4;
            this.numericUpDown_decelerate.ValueChanged += new System.EventHandler(this.decelerate_changed);
            // 
            // numericUpDown_acelerate
            // 
            this.numericUpDown_acelerate.Location = new System.Drawing.Point(134, 163);
            this.numericUpDown_acelerate.Name = "numericUpDown_acelerate";
            this.numericUpDown_acelerate.Size = new System.Drawing.Size(120, 21);
            this.numericUpDown_acelerate.TabIndex = 4;
            this.numericUpDown_acelerate.ValueChanged += new System.EventHandler(this.acelerate_changed);
            // 
            // departurearrivelnud
            // 
            this.departurearrivelnud.Location = new System.Drawing.Point(134, 108);
            this.departurearrivelnud.Name = "departurearrivelnud";
            this.departurearrivelnud.Size = new System.Drawing.Size(120, 21);
            this.departurearrivelnud.TabIndex = 3;
            this.departurearrivelnud.ValueChanged += new System.EventHandler(this.departurearrivelnud_valuechanged);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(30, 98);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(0, 12);
            this.label4.TabIndex = 1;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(3, 201);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(95, 12);
            this.label11.TabIndex = 1;
            this.label11.Text = "Decelerate Time";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(3, 165);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(89, 12);
            this.label10.TabIndex = 1;
            this.label10.Text = "Acelerate Time";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(70, 57);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(0, 12);
            this.label1.TabIndex = 1;
            // 
            // Cancelbtn
            // 
            this.Cancelbtn.Location = new System.Drawing.Point(472, 446);
            this.Cancelbtn.Name = "Cancelbtn";
            this.Cancelbtn.Size = new System.Drawing.Size(75, 23);
            this.Cancelbtn.TabIndex = 6;
            this.Cancelbtn.Text = "Cancel";
            this.Cancelbtn.UseVisualStyleBackColor = true;
            this.Cancelbtn.Click += new System.EventHandler(this.Paremeter_Setting_Cancelbtn_Click);
            // 
            // Tab_control
            // 
            this.Tab_control.Controls.Add(this.tabPage_slack);
            this.Tab_control.Controls.Add(this.tabPage2);
            this.Tab_control.Location = new System.Drawing.Point(316, 38);
            this.Tab_control.Name = "Tab_control";
            this.Tab_control.SelectedIndex = 0;
            this.Tab_control.Size = new System.Drawing.Size(272, 346);
            this.Tab_control.TabIndex = 0;
            // 
            // tabPage_slack
            // 
            this.tabPage_slack.Controls.Add(this.comboBox_yesno);
            this.tabPage_slack.Controls.Add(this.textBox_departure_slack);
            this.tabPage_slack.Controls.Add(this.textBox_arrive_slack);
            this.tabPage_slack.Controls.Add(this.label14);
            this.tabPage_slack.Controls.Add(this.label13);
            this.tabPage_slack.Controls.Add(this.label12);
            this.tabPage_slack.Location = new System.Drawing.Point(4, 22);
            this.tabPage_slack.Name = "tabPage_slack";
            this.tabPage_slack.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage_slack.Size = new System.Drawing.Size(264, 320);
            this.tabPage_slack.TabIndex = 0;
            this.tabPage_slack.Text = "Slack";
            this.tabPage_slack.UseVisualStyleBackColor = true;
            // 
            // comboBox_yesno
            // 
            this.comboBox_yesno.FormattingEnabled = true;
            this.comboBox_yesno.Location = new System.Drawing.Point(132, 67);
            this.comboBox_yesno.Name = "comboBox_yesno";
            this.comboBox_yesno.Size = new System.Drawing.Size(101, 20);
            this.comboBox_yesno.TabIndex = 7;
            this.comboBox_yesno.SelectedIndexChanged += new System.EventHandler(this.yesno_selectindexchanged);
            // 
            // textBox_departure_slack
            // 
            this.textBox_departure_slack.Location = new System.Drawing.Point(133, 37);
            this.textBox_departure_slack.Name = "textBox_departure_slack";
            this.textBox_departure_slack.Size = new System.Drawing.Size(100, 21);
            this.textBox_departure_slack.TabIndex = 1;
            this.textBox_departure_slack.TextChanged += new System.EventHandler(this.departure_slack_textchanged);
            // 
            // textBox_arrive_slack
            // 
            this.textBox_arrive_slack.Location = new System.Drawing.Point(133, 10);
            this.textBox_arrive_slack.Name = "textBox_arrive_slack";
            this.textBox_arrive_slack.Size = new System.Drawing.Size(100, 21);
            this.textBox_arrive_slack.TabIndex = 1;
            this.textBox_arrive_slack.TextChanged += new System.EventHandler(this.arrive_slack_textchanged);
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(19, 67);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(35, 12);
            this.label14.TabIndex = 0;
            this.label14.Text = "YesNo";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(19, 43);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(95, 12);
            this.label13.TabIndex = 0;
            this.label13.Text = "Departure slack";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(19, 19);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(77, 12);
            this.label12.TabIndex = 0;
            this.label12.Text = "Arrive slack";
            // 
            // tabPage2
            // 
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(264, 107);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Other";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // ParemeterSetting
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(613, 484);
            this.Controls.Add(this.Tab_control);
            this.Controls.Add(this.Paremeter_Setting_Savebtn);
            this.Controls.Add(this.Paremeter_Setting_Exitbtn);
            this.Controls.Add(this.Cancelbtn);
            this.Controls.Add(this.Paremeter_Setting_Surebtn);
            this.Controls.Add(this.panel_headway);
            this.Name = "ParemeterSetting";
            this.Text = "ParemeterSetting";
            ((System.ComponentModel.ISupportInitialize)(this.arrivearrivenud)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.departuredeparturenud)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.departurearrivehnud)).EndInit();
            this.panel_headway.ResumeLayout(false);
            this.panel_headway.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown_decelerate)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown_acelerate)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.departurearrivelnud)).EndInit();
            this.Tab_control.ResumeLayout(false);
            this.tabPage_slack.ResumeLayout(false);
            this.tabPage_slack.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Button Paremeter_Setting_Savebtn;
        private System.Windows.Forms.Button Paremeter_Setting_Exitbtn;
        private System.Windows.Forms.Label DoubleTracklbl;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.NumericUpDown departurearrivehnud;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label SingleTracklbl;
        private System.Windows.Forms.Button Paremeter_Setting_Surebtn;
        private System.Windows.Forms.Panel panel_headway;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.NumericUpDown arrivearrivenud;
        private System.Windows.Forms.NumericUpDown departuredeparturenud;
        private System.Windows.Forms.NumericUpDown departurearrivelnud;
        private System.Windows.Forms.Button Cancelbtn;
        private System.Windows.Forms.NumericUpDown numericUpDown_decelerate;
        private System.Windows.Forms.NumericUpDown numericUpDown_acelerate;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TabControl Tab_control;
        private System.Windows.Forms.TabPage tabPage_slack;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.ComboBox comboBox_yesno;
        private System.Windows.Forms.TextBox textBox_departure_slack;
        private System.Windows.Forms.TextBox textBox_arrive_slack;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label12;
    }
}