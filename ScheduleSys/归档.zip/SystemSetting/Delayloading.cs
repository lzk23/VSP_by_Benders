﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ScheduleSys.SystemSetting
{
    public partial class Delayloading : Form
    {
        Graph g;
        bool saveflag;
        int schedulefor;
        public Delayloading()
        {
            InitializeComponent();
            saveflag = true;
        }
        public Delayloading(Graph g,int schedulefor):this()
        {
            this.g=g;
            this.schedulefor = schedulefor;
            InitialValue();
        }
        //初始化控件的值
        void InitialValue()
        {
            if(schedulefor==0)
            {
                //添加列车前需要防止触发相应的事件
                comboBox_trainlist.SelectedIndexChanged -= combobox_delay_train_changed;
                foreach (Train train in g.trainlist)
                {
                    comboBox_trainlist.Items.Add(train.name);
                }
                comboBox_trainlist.SelectedIndexChanged += combobox_delay_train_changed;
                //comboBox_trainlist.SelectedValue = "K58/5";//No way
                string trainname = DataReadWrite.ReadIniData("Delay", "trainname", "", Application.StartupPath + "\\Paremeter.ini");
                Train initialtrain = g.GetTrainByName(trainname);
                if (initialtrain != null)
                {
                    comboBox_trainlist.SelectedIndex = initialtrain.index;
                    textBox_delaytime.Text = DataReadWrite.ReadIniData("Delay", "delaytime", "", Application.StartupPath + "\\Paremeter.ini");
                    comboBox_stationlist.SelectedItem = DataReadWrite.ReadIniData("Delay", "stationname", "", Application.StartupPath + "\\Paremeter.ini");
                }
            }
            else
            {
                for(int station_index=0;station_index<g.stationlist.Count()-1;station_index++)
                {
                    Station station_ = g.stationlist[station_index];
                    //comboBox_section.Items.Add(station_.name + "-" + station_.nextstationname);
                    comboBox_section.Items.Add(station_.name);
                }
                string firststationname = DataReadWrite.ReadIniData("Disturbance", "firststation", "", Application.StartupPath + "\\Paremeter.ini");
                Station station = g.GetStationByName(firststationname);
                if(station!=null)
                {
                    comboBox_section.SelectedIndex = station.index;
                    textBox_starttime.Text = DataReadWrite.ReadIniData("Disturbance", "begintime", "", Application.StartupPath + "\\Paremeter.ini");
                    textBox_endtime.Text = DataReadWrite.ReadIniData("Disturbance", "endtime", "", Application.StartupPath + "\\Paremeter.ini");
                }                
            }            
        }

        private void button_sure_Click(object sender, EventArgs e)
        {
            if (saveflag == true)
            {
                return;
            }
            if (MessageBox.Show("Are you sure to save？", "Message", MessageBoxButtons.YesNo, MessageBoxIcon.Exclamation) == DialogResult.Yes)
            {
                if(schedulefor==0)
                {
                    DataReadWrite.WriteIniData("Delay", "trainname", comboBox_trainlist.SelectedItem.ToString(), Application.StartupPath + "\\Paremeter.ini");
                    DataReadWrite.WriteIniData("Delay", "delaytime", textBox_delaytime.Text, Application.StartupPath + "\\Paremeter.ini");
                    DataReadWrite.WriteIniData("Delay", "stationname", comboBox_stationlist.SelectedItem.ToString(), Application.StartupPath + "\\Paremeter.ini");
                    saveflag = true;
                }
                else
                {
                    DataReadWrite.WriteIniData("Disturbance", "firststation", comboBox_section.SelectedItem.ToString(), Application.StartupPath + "\\Paremeter.ini");
                    DataReadWrite.WriteIniData("Disturbance", "begintime", textBox_starttime.Text, Application.StartupPath + "\\Paremeter.ini");
                    DataReadWrite.WriteIniData("Disturbance", "endtime", textBox_endtime.Text, Application.StartupPath + "\\Paremeter.ini");
                    saveflag = true;
                }
            }
        }


        private void textbox_delaytime_valuechanged(object sender, EventArgs e)
        {
            saveflag = false;
        }

        private void button_cancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        //根据选择的车站，相应更改车站集
        private void combobox_delay_train_changed(object sender, EventArgs e)
        {
            comboBox_stationlist.Items.Clear();
            string selecttrainname = comboBox_trainlist.SelectedItem.ToString();
            Train selecttrain = g.GetTrainByName(selecttrainname);
            //添加车站名到控件
            foreach (string station_name in selecttrain.past_stations_name)
            {
                comboBox_stationlist.Items.Add(station_name);
            }
            comboBox_stationlist.SelectedIndex=0;

            saveflag = false;
        }

        private void broken_section_select_index_changed(object sender, EventArgs e)
        {
            saveflag = false;
        }
    }
}
