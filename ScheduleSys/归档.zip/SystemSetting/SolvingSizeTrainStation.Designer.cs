﻿namespace ScheduleSys.SystemSetting
{
    partial class SolvingSizeTrainStation
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.checkedListBox_train = new System.Windows.Forms.CheckedListBox();
            this.checkedListBox_station = new System.Windows.Forms.CheckedListBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.button_save = new System.Windows.Forms.Button();
            this.button_cancel = new System.Windows.Forms.Button();
            this.button_exit = new System.Windows.Forms.Button();
            this.button_reread = new System.Windows.Forms.Button();
            this.button_train_select_all = new System.Windows.Forms.Button();
            this.button_station_select_all = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.textBox_trainnumber = new System.Windows.Forms.TextBox();
            this.textBox_stationnumber = new System.Windows.Forms.TextBox();
            this.btn_cancel_all_train = new System.Windows.Forms.Button();
            this.btn_calcel_all_station = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // checkedListBox_train
            // 
            this.checkedListBox_train.FormattingEnabled = true;
            this.checkedListBox_train.Location = new System.Drawing.Point(33, 33);
            this.checkedListBox_train.Name = "checkedListBox_train";
            this.checkedListBox_train.Size = new System.Drawing.Size(158, 404);
            this.checkedListBox_train.TabIndex = 0;
            this.checkedListBox_train.SelectedValueChanged += new System.EventHandler(this.train_select_index_changed);
            // 
            // checkedListBox_station
            // 
            this.checkedListBox_station.FormattingEnabled = true;
            this.checkedListBox_station.Location = new System.Drawing.Point(250, 33);
            this.checkedListBox_station.Name = "checkedListBox_station";
            this.checkedListBox_station.Size = new System.Drawing.Size(164, 404);
            this.checkedListBox_station.TabIndex = 1;
            this.checkedListBox_station.SelectedIndexChanged += new System.EventHandler(this.station_select_index_changed);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(35, 12);
            this.label1.TabIndex = 2;
            this.label1.Text = "Train";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(248, 9);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(47, 12);
            this.label2.TabIndex = 2;
            this.label2.Text = "Station";
            // 
            // button_save
            // 
            this.button_save.Location = new System.Drawing.Point(464, 179);
            this.button_save.Name = "button_save";
            this.button_save.Size = new System.Drawing.Size(75, 23);
            this.button_save.TabIndex = 3;
            this.button_save.Text = "Save";
            this.button_save.UseVisualStyleBackColor = true;
            this.button_save.Click += new System.EventHandler(this.button_save_Click);
            // 
            // button_cancel
            // 
            this.button_cancel.Location = new System.Drawing.Point(464, 245);
            this.button_cancel.Name = "button_cancel";
            this.button_cancel.Size = new System.Drawing.Size(75, 23);
            this.button_cancel.TabIndex = 3;
            this.button_cancel.Text = "Cancel";
            this.button_cancel.UseVisualStyleBackColor = true;
            this.button_cancel.Click += new System.EventHandler(this.button_cancel_Click);
            // 
            // button_exit
            // 
            this.button_exit.Location = new System.Drawing.Point(464, 314);
            this.button_exit.Name = "button_exit";
            this.button_exit.Size = new System.Drawing.Size(75, 23);
            this.button_exit.TabIndex = 3;
            this.button_exit.Text = "Exit";
            this.button_exit.UseVisualStyleBackColor = true;
            this.button_exit.Click += new System.EventHandler(this.button_exit_Click);
            // 
            // button_reread
            // 
            this.button_reread.Location = new System.Drawing.Point(431, 381);
            this.button_reread.Name = "button_reread";
            this.button_reread.Size = new System.Drawing.Size(123, 23);
            this.button_reread.TabIndex = 4;
            this.button_reread.Text = "ReReadTimetable";
            this.button_reread.UseVisualStyleBackColor = true;
            this.button_reread.Click += new System.EventHandler(this.button_reread_Click);
            // 
            // button_train_select_all
            // 
            this.button_train_select_all.Location = new System.Drawing.Point(53, 4);
            this.button_train_select_all.Name = "button_train_select_all";
            this.button_train_select_all.Size = new System.Drawing.Size(75, 23);
            this.button_train_select_all.TabIndex = 5;
            this.button_train_select_all.Text = "Select All";
            this.button_train_select_all.UseVisualStyleBackColor = true;
            this.button_train_select_all.Click += new System.EventHandler(this.button_train_select_all_Click);
            // 
            // button_station_select_all
            // 
            this.button_station_select_all.Location = new System.Drawing.Point(310, 4);
            this.button_station_select_all.Name = "button_station_select_all";
            this.button_station_select_all.Size = new System.Drawing.Size(75, 23);
            this.button_station_select_all.TabIndex = 5;
            this.button_station_select_all.Text = "Select All";
            this.button_station_select_all.UseVisualStyleBackColor = true;
            this.button_station_select_all.Click += new System.EventHandler(this.button_station_select_all_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(429, 119);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(89, 12);
            this.label3.TabIndex = 6;
            this.label3.Text = "Station number";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(429, 60);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(77, 12);
            this.label4.TabIndex = 7;
            this.label4.Text = "Train number";
            // 
            // textBox_trainnumber
            // 
            this.textBox_trainnumber.Location = new System.Drawing.Point(439, 84);
            this.textBox_trainnumber.Name = "textBox_trainnumber";
            this.textBox_trainnumber.Size = new System.Drawing.Size(100, 21);
            this.textBox_trainnumber.TabIndex = 8;
            // 
            // textBox_stationnumber
            // 
            this.textBox_stationnumber.Location = new System.Drawing.Point(439, 138);
            this.textBox_stationnumber.Name = "textBox_stationnumber";
            this.textBox_stationnumber.Size = new System.Drawing.Size(100, 21);
            this.textBox_stationnumber.TabIndex = 8;
            // 
            // btn_cancel_all_train
            // 
            this.btn_cancel_all_train.Location = new System.Drawing.Point(134, 4);
            this.btn_cancel_all_train.Name = "btn_cancel_all_train";
            this.btn_cancel_all_train.Size = new System.Drawing.Size(83, 23);
            this.btn_cancel_all_train.TabIndex = 9;
            this.btn_cancel_all_train.Text = " Cancel All";
            this.btn_cancel_all_train.UseVisualStyleBackColor = true;
            this.btn_cancel_all_train.Click += new System.EventHandler(this.btn_cancel_all_train_Click);
            // 
            // btn_calcel_all_station
            // 
            this.btn_calcel_all_station.Location = new System.Drawing.Point(391, 4);
            this.btn_calcel_all_station.Name = "btn_calcel_all_station";
            this.btn_calcel_all_station.Size = new System.Drawing.Size(86, 23);
            this.btn_calcel_all_station.TabIndex = 9;
            this.btn_calcel_all_station.Text = "Cancel ALL";
            this.btn_calcel_all_station.UseVisualStyleBackColor = true;
            this.btn_calcel_all_station.Click += new System.EventHandler(this.btn_calcel_all_station_Click);
            // 
            // SolvingSizeTrainStation
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(568, 449);
            this.Controls.Add(this.btn_calcel_all_station);
            this.Controls.Add(this.btn_cancel_all_train);
            this.Controls.Add(this.textBox_stationnumber);
            this.Controls.Add(this.textBox_trainnumber);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.button_station_select_all);
            this.Controls.Add(this.button_train_select_all);
            this.Controls.Add(this.button_reread);
            this.Controls.Add(this.button_exit);
            this.Controls.Add(this.button_cancel);
            this.Controls.Add(this.button_save);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.checkedListBox_station);
            this.Controls.Add(this.checkedListBox_train);
            this.Name = "SolvingSizeTrainStation";
            this.Text = "SolvingSizeTrainStation";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.CheckedListBox checkedListBox_train;
        private System.Windows.Forms.CheckedListBox checkedListBox_station;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button button_save;
        private System.Windows.Forms.Button button_cancel;
        private System.Windows.Forms.Button button_exit;
        private System.Windows.Forms.Button button_reread;
        private System.Windows.Forms.Button button_train_select_all;
        private System.Windows.Forms.Button button_station_select_all;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox textBox_trainnumber;
        private System.Windows.Forms.TextBox textBox_stationnumber;
        private System.Windows.Forms.Button btn_cancel_all_train;
        private System.Windows.Forms.Button btn_calcel_all_station;
    }
}