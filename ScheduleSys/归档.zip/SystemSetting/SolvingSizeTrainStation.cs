﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ScheduleSys.SystemSetting
{
    public partial class SolvingSizeTrainStation : Form
    {
        MainForm mainform;
        bool saveflag;
        string[] trainitem_key;
        string[] station_key;
        public SolvingSizeTrainStation(Graph g,MainForm mainform)
        {
            InitializeComponent();
            saveflag = true;
            this.mainform=mainform;
            Initial(g);
        }
        //初始化控件的值
        void Initial(Graph g)
        {
            //得到所有的Item key
            trainitem_key = DataReadWrite.INIGetAllItemKeys(Application.StartupPath + "\\Paremeter.ini", "SolvingSizeTrain");           
            foreach(string train_name in trainitem_key)
            {                
                if (DataReadWrite.ReadIniData("SolvingSizeTrain", train_name, "", Application.StartupPath + "\\Paremeter.ini") == "1")
                {
                    checkedListBox_train.Items.Add(train_name,true);
                }
                else
                {
                    checkedListBox_train.Items.Add(train_name,false);
                }
            }
            station_key = DataReadWrite.INIGetAllItemKeys(Application.StartupPath + "\\Paremeter.ini", "SolvingSizeStation");
            foreach(string station_name in station_key)
            {
                if (DataReadWrite.ReadIniData("SolvingSizeStation",station_name,"",Application.StartupPath + "\\Paremeter.ini") == "1")
                {
                    checkedListBox_station.Items.Add(station_name, true);
                } 
                else
                {
                    checkedListBox_station.Items.Add(station_name, false);
                }
            }
        }
        //全部选择，参数为列车还是车站
        private void ALLTrainSelectOrNot(bool flag)
        {
            for(int i=0;i<checkedListBox_train.Items.Count;i++)
            {
                checkedListBox_train.SetItemChecked(i, flag);
                //checkedListBox1.SetItemCheckState(i, CheckState.Checked);
            }
        }
        private void ALLStationSelectOrNot(bool flag)
        {
            for (int i = 0; i < checkedListBox_station.Items.Count; i++)
            {
                checkedListBox_station.SetItemChecked(i, flag);
                //checkedListBox1.SetItemCheckState(i, CheckState.Checked);
            }
        }
        //累计有多少个列车被选择
        private int　AddUpSelectTrain()
        {
            int count = 0;
            for (int i = 0; i < checkedListBox_train.Items.Count; i++)
            {
                if (checkedListBox_train.GetItemChecked(i))
                {
                    count++;
                }                
            }
            return count;
        }
        //累计有多少个车站被选择
        private int AddUpSelectStation()
        {
            int count = 0;
            for (int i = 0; i < checkedListBox_station.Items.Count; i++)
            {
                if (checkedListBox_station.GetItemChecked(i))
                {
                    count++;
                }
            }
            return count;
        }
        //选择的车站发生改变
        private void station_select_index_changed(object sender, EventArgs e)
        {
            saveflag = false;
            textBox_trainnumber.Text = AddUpSelectTrain().ToString();
        }
        //选择的列车发生该表
        private void train_select_index_changed(object sender, EventArgs e)
        {
            saveflag = false;
            textBox_stationnumber.Text = AddUpSelectStation().ToString();
        }
        //点击保存按钮
        private void button_save_Click(object sender, EventArgs e)
        {
            if (saveflag == true)
            {
                return;
            }
            if (MessageBox.Show("Are you sure to save？", "Message", MessageBoxButtons.YesNo, MessageBoxIcon.Exclamation) == DialogResult.Yes)
            {
                for (int trainitem_index = 0; trainitem_index < trainitem_key.Count();trainitem_index++ )
                {
                    if(checkedListBox_train.GetItemChecked(trainitem_index)==true)
                    {
                        DataReadWrite.WriteIniData("SolvingSizeTrain",trainitem_key[trainitem_index],"1",Application.StartupPath+"\\Paremeter.ini");
                    }
                    else
                    {
                        DataReadWrite.WriteIniData("SolvingSizeTrain", trainitem_key[trainitem_index], "0", Application.StartupPath + "\\Paremeter.ini");
                    }
                }

                for (int stationitem_index = 0; stationitem_index < station_key.Count(); stationitem_index++)
                {
                    if (checkedListBox_station.GetItemChecked(stationitem_index) == true)
                    {
                        DataReadWrite.WriteIniData("SolvingSizeStation", station_key[stationitem_index], "1", Application.StartupPath + "\\Paremeter.ini");
                    }
                    else
                    {
                        DataReadWrite.WriteIniData("SolvingSizeStation", station_key[stationitem_index], "0", Application.StartupPath + "\\Paremeter.ini");
                    }
                }
                saveflag = true;
            }
        }

        private void button_cancel_Click(object sender, EventArgs e)
        {
            if (saveflag == false)
            {
                button_save.PerformClick();
                this.Close();
            }
            else
            {
                this.Close();
            }
        }

        private void button_exit_Click(object sender, EventArgs e)
        {
            if (saveflag == false)
            {
                button_save.PerformClick();
                this.Close();
            }
            else
            {
                this.Close();
            }
        }
        //重新加载时刻表
        private void button_reread_Click(object sender, EventArgs e)
        {
            if (saveflag == false)
            {
                MessageBox.Show("Please save your selections before reread.", "Message");
                return;
            }
            if (MessageBox.Show("Are you sure to reread train timetable？", "Message", MessageBoxButtons.YesNo, MessageBoxIcon.Exclamation) == DialogResult.Yes)
            {
                mainform.ClearData();
                mainform.improtToolStripMenuItem.PerformClick();
            }
        }
        //全选所有列车
        private void button_train_select_all_Click(object sender, EventArgs e)
        {
            ALLTrainSelectOrNot(true);
            saveflag = false;
        }
        //全选所有车站
        private void button_station_select_all_Click(object sender, EventArgs e)
        {
            ALLStationSelectOrNot(true);
            saveflag = false;
        }

        private void btn_cancel_all_train_Click(object sender, EventArgs e)
        {
            ALLTrainSelectOrNot(false);
            saveflag = false;
        }

        private void btn_calcel_all_station_Click(object sender, EventArgs e)
        {
            ALLStationSelectOrNot(false);
            saveflag = false;
        }

    }
}
