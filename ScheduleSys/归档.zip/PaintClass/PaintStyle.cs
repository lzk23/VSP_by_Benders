﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ScheduleSys.PaintClass
{
    public class PaintStyle
    {
        public bool color;
        public bool trainname;
        public bool trainindex;
        public bool arrivetime;
        public bool departuretime;
        public bool stock;
        public Algorithm.Path path;
        public List<Algorithm.Path> best_path_list;

        public PaintStyle()
        {

        }
        public PaintStyle(bool color, bool trainname, bool trainindex,
            bool arrivetime, bool departuretime,bool stock,Algorithm.Path path)
        {
            this.color = color;
            this.trainname = trainname;
            this.trainindex = trainindex;
            this.arrivetime = arrivetime;
            this.departuretime = departuretime;
            this.stock = stock;
            this.path = path;
        }
        public PaintStyle(PaintStyle _paintstyle)
        {
            this.color = _paintstyle.color;
            this.trainname =_paintstyle.trainname;
            this.trainindex = _paintstyle.trainindex;
            this.arrivetime = _paintstyle.arrivetime;
            this.departuretime =_paintstyle.departuretime;
            this.stock = _paintstyle.stock;
            this.path =_paintstyle.path;
            this.best_path_list = _paintstyle.best_path_list;
        }
    }
}
