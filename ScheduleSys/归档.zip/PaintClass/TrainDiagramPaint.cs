﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ScheduleSys.PaintClass
{
    class TrainDiagramPaint
    {
        Bitmap BmpDiagram;
        Graphics DiagramGraphic;
        PictureBox picturebox;
        Graph g;
        Graph new_g;
        Dictionary<string, float> stationnametoy;
        List<Algorithm.ConflictEventPair> eventpairs;
        //int[] timespan;//调度的时段
        int[] beginandendhour;//开始和结束的小时
        float[] leftandrightx;//调度时段的界限投影到x轴
        float timezoom;
        public TrainDiagramPaint()
        {
            beginandendhour=new int[2];
            leftandrightx = new float[2];
            
        }
        public TrainDiagramPaint(PictureBox picturebox, Graph g,Station station,double[] arrivetime,double[] departuretime)
        {

        }
        public TrainDiagramPaint(PictureBox picturebox,Graph g, PaintStyle paintstyle)
            : this()
        {
            BmpDiagram = new Bitmap(4000,700);
            this.g = g;
            this.picturebox = picturebox;
            DiagramGraphic = Graphics.FromImage(BmpDiagram);        
            paintbasicframe();
            paintdiagram(paintstyle);
            picturebox.Image = BmpDiagram;
            picturebox.BackColor = Color.White;
        }
        public TrainDiagramPaint(PictureBox picturebox, Graph g, Graph new_g,PaintStyle paintstyle)
            : this()
        {
            BmpDiagram = new Bitmap(4000, 700);
            this.g = g;
            this.new_g = new_g;
            this.picturebox = picturebox;
            DiagramGraphic = Graphics.FromImage(BmpDiagram);
            paintbasicframe();
            paintdiagram(paintstyle);
            picturebox.Image = BmpDiagram;
            picturebox.BackColor = Color.White;
        }
        //显示冲突的重载
        public TrainDiagramPaint(PictureBox picturebox, Graph g, List<Algorithm.ConflictEventPair> eventpairs):this()
        {
            BmpDiagram = (Bitmap)picturebox.Image;
            this.g = g;
            this.eventpairs = eventpairs;
            this.picturebox = picturebox;
            DiagramGraphic = Graphics.FromImage(BmpDiagram);
            paintconflict();//画冲突
            picturebox.Image = BmpDiagram;
            picturebox.BackColor = Color.White;
        }
        void paintconflict()
        {
            Pen pen_conflict = new Pen(Color.Red, 2);
            int high=20;
            foreach (Algorithm.ConflictEventPair pair in eventpairs)
            {
                //if(pair.dwelling_conflict==true)
                //{
                //    float startx= MapTimeToX(g.GetArriveTimeByTrainStation(pair.first_event.train_name, pair.first_event.end_station_name));
                //    float endx=MapTimeToX(g.GetArriveTimeByTrainStation(pair.first_event.train_name, pair.first_event.end_station_name));
                //    float y=stationnametoy[pair.first_event.end_station_name];
                //    DiagramGraphic.DrawArc(pen_conflict,startx,y-high,endx-startx,high,180,0);
                //}
            }
            pen_conflict.Dispose();
        }
        
        Color GetColorByIndex(int index)
        {
            switch(index)
            {
                case 0:
                    return Color.OrangeRed;//k58/5
                case 1:
                    return Color.Azure;//k518/5
                case 2:
                    return Color.LightYellow;//k101/4/1
                case 3:
                    return Color.PaleGreen;//D88/5
                case 4:
                    return Color.Black;//1230/27
                case 5:
                    return Color.CadetBlue;//1013
                case 6:
                    return Color.Purple;//10625
                case 7:
                    return Color.DarkCyan;//11301
                case 8:
                    return Color.PowderBlue;//23005
                case 9:
                    return Color.DarkOliveGreen;//11305
                case 10:
                    return Color.DarkOrange;//T114/1
                case 11:
                    return Color.DarkSlateBlue;//K190/87
                case 12:
                    return Color.DarkTurquoise;//T54
                case 13:
                    return Color.DarkViolet;//K8471
                case 14:
                    return Color.DeepPink;//K374/1
                case 15:
                    return Color.DeepSkyBlue;//T118/5
                case 16:
                    return Color.DimGray;//T284/1
                case 17:
                    return Color.Firebrick;//T65
                case 18:
                    return Color.ForestGreen;//T131/4/1
                case 19:
                    return Color.Gainsboro;//K559/8
                case 20:
                    return Color.Goldenrod;//T166/3
                case 21:
                    return Color.Honeydew;//140/37
                case 22:
                    return Color.CadetBlue;
                case 23:
                    return Color.DarkGreen;
                case 24:
                    return Color.DarkOrange;
                case 25:
                    return Color.Gold;
                default:
                    return Color.Black;

            }
        }
        /// <summary>
        /// 是否带颜色作为参数
        /// </summary>
        /// <param name="color"></param>
        void paintdiagram(PaintStyle paintstyle)
        {
            Pen trainpath = new Pen(Color.Black, 2);
            
            Font font = new Font("宋体", 15);
            Brush brush = new SolidBrush(Color.Black);
            int trainname_interval = 40;
            //写倾斜的文字
            GraphicsText graphicsText = new GraphicsText(DiagramGraphic);
            StringFormat format = new StringFormat();
            format.Alignment = StringAlignment.Center;
            format.LineAlignment = StringAlignment.Center; 
            //Color traincolor=Color.Black;
            foreach(Train train in g.trainlist)
            {
                for(int station_index=0;station_index<train.past_stations_name.Count()-1;station_index++)
                {
                    
                    Station station=g.GetStationByName(train.past_stations_name[station_index]);
                    Station stationnext = g.GetStationByName(train.past_stations_name[station_index+1]);
                    float departuretimemaptox = MapTimeToX(g.GetDepartureTimeByTrainStation(train.name, station.name));//离开车站的时间
                    float stationy = stationnametoy[station.name];
                    float arrivetimemaptox = MapTimeToX(g.GetArriveTimeByTrainStation(train.name, stationnext.name));//到达下一个车站的时间
                    float nextstationy = stationnametoy[stationnext.name];
                    if(new_g!=null)
                    {
                        departuretimemaptox = MapTimeToX(new_g.GetDepartureTimeByTrainStation(train.name, station.name));//离开车站的时间
                        arrivetimemaptox = MapTimeToX(new_g.GetArriveTimeByTrainStation(train.name, stationnext.name));//到达下一个车站的时间
                    }
                    
                    if (paintstyle.color == true)
                    {
                        trainpath.Color = ColorTranslator.FromHtml(DataReadWrite.ReadIniData("TrainColor", train.stock_index.ToString()
                            , "", Application.StartupPath + "\\Paremeter.ini")); ;//标示颜色
                        //trainpath.Color = GetColorByIndex(train.stock_index);
                        brush = new SolidBrush(trainpath.Color);
                    }
                    if(train.trainselect==true)
                    {
                        trainpath.Width = 4;
                    }
                    else
                    {
                        trainpath.Width = 2;
                    }
                    //重绘制动车组交路
                    if (paintstyle.path != null)
                    {
                        if(paintstyle.path.train_index_list.Contains(train.index))
                        {
                            trainpath.Color = Color.Green;
                            trainpath.Width = 4;
                        }
                    }
                    //画列车运行线
                    DiagramGraphic.DrawLine(trainpath,departuretimemaptox,stationy,arrivetimemaptox,nextstationy);
                    //如何运行线发生了偏移，画出原来的运行线
                    if (new_g != null)
                    {
                        if(g.GetDepartureTimeByTrainStation(train.name, station.name)!=new_g.GetDepartureTimeByTrainStation(train.name,station.name))
                        {
                            trainpath.DashStyle = DashStyle.Custom;
                            trainpath.DashPattern = new float[] { 1f, 1f };
                            float origin_departuretimemaptox = MapTimeToX(g.GetDepartureTimeByTrainStation(train.name, station.name));//离开车站的时间
                            float origin_arrivetimemaptox = MapTimeToX(g.GetArriveTimeByTrainStation(train.name, stationnext.name));//到达下一个车站的时间
                            DiagramGraphic.DrawLine(trainpath, origin_departuretimemaptox, stationy, origin_arrivetimemaptox, nextstationy);
                            trainpath.DashStyle = DashStyle.Solid;
                        }                 
                    }
                    int multi = 1;
                    if (train.direction == 0)
                    {
                        multi = -1;
                    }
                    //标识动车组
                    if (station_index == 0&&paintstyle.stock==true)
                    {
                        graphicsText.DrawString("R" + train.stock_index.ToString(), font, brush, new PointF(departuretimemaptox, stationy - trainname_interval)
                            , format, 45f);
                    }
                    //标示列车名
                    if (paintstyle.trainname == true && station_index == 0)
                    {
                        DiagramGraphic.DrawLine(trainpath, departuretimemaptox, stationy - 20 * multi, departuretimemaptox, stationy);          
                        //DiagramGraphic.DrawString(train.name, font, brush, entertimemaptox, stationy - trainname_interval);
                        graphicsText.DrawString(train.name, font, brush, new PointF(departuretimemaptox, stationy - trainname_interval * multi)
                            ,format,45f);
                    }
                    if (paintstyle.trainindex == true)
                    {
                        DiagramGraphic.DrawLine(trainpath, arrivetimemaptox, stationnametoy[train.end_station_name],
                                arrivetimemaptox, stationnametoy[train.end_station_name] + 20 * multi);
                        graphicsText.DrawString("T(" + train.index + ")", font, brush,
                            new PointF(arrivetimemaptox, stationnametoy[train.end_station_name] + multi * trainname_interval)
                            , format, -90f);
                        //DiagramGraphic.DrawString("T(" + train.index+ ")", font, brush, departtimemaptox, stationnametoy[train.end_station_name] + trainname_interval);
                    }
                    //标示到达时刻
                    if (paintstyle.arrivetime == true && train.trainselect == true)
                    {
                        DiagramGraphic.DrawString(g.GetArriveTimeByTrainStation(train.name, stationnext.name).ToString(),
                            font, brush, departuretimemaptox, stationy);
                    }
                    //标示出发时刻
                    if (paintstyle.departuretime == true && train.trainselect == true)
                    {
                        DiagramGraphic.DrawString(g.GetDepartureTimeByTrainStation(train.name, station.name).ToString(),
                            font, brush, departuretimemaptox, stationy - trainname_interval);
                    }
                }
            } 
            
            trainpath.Dispose();
            font.Dispose();
            brush.Dispose();
        }
        //画底图
        void paintbasicframe()
        {
            XStander();
            StationYMap();
            Pen basicframework_pen = new Pen(Color.Gray,1);//底图的画笔
            Pen basicframework_pen_2 = new Pen(Color.Gray, 3);//底图的画笔
            Font font=new Font("宋体",10);
            Brush brush=new SolidBrush(Color.Black);
            int stationnamedeviatelinex=60;//站名标示偏离线x方向的距离
            int stationnamedeviateliney=5;//站名标示偏离线y方向的距离
            //画横轴
            foreach(Station station in g.stationlist)
            {
                DiagramGraphic.DrawLine(basicframework_pen, leftandrightx[0], stationnametoy[station.name]
                        , leftandrightx[1], stationnametoy[station.name]);
                DiagramGraphic.DrawString(station.name+"("+station.index+")", font, brush, leftandrightx[0] - stationnamedeviatelinex,
                    stationnametoy[station.name] - stationnamedeviateliney);
            }            
            //画竖线
            int line_num = (int)((leftandrightx[1] - leftandrightx[0]) / timezoom) * 6;
            for(int line_index=0;line_index<=line_num;line_index++)
            {
                if(line_index%6==0)
                {
                    DiagramGraphic.DrawLine(basicframework_pen_2, leftandrightx[0] + line_index * timezoom / 6, stationnametoy[g.stationlist[0].name],
                    leftandrightx[0] + line_index * timezoom / 6, stationnametoy[g.stationlist.Last().name]);
                    //标注横轴的时间
                    DiagramGraphic.DrawString((beginandendhour[0] + (int)(line_index/6)).ToString(), font, brush,
                    beginandendhour[0] + (int)(line_index / 6) * timezoom + 50, stationnametoy[g.stationlist.Last().name] + 20);
                }
                else
                {
                    DiagramGraphic.DrawLine(basicframework_pen, leftandrightx[0] + line_index * timezoom / 6, stationnametoy[g.stationlist[0].name],
                   leftandrightx[0] + line_index * timezoom / 6, stationnametoy[g.stationlist.Last().name]);
                }
                             
            }
            
            for (int time_index=0; time_index < beginandendhour[1] - beginandendhour[0];time_index++ )
            {
               
            }               
            basicframework_pen.Dispose();
            font.Dispose();
            brush.Dispose();
        }
        //给每个车站一个y坐标,车站投影到y轴
        void StationYMap()
        {
            stationnametoy=new Dictionary<string,float>();
            float stationzoom = 2;//空间轴放大缩小倍数
            //float stationzoom = 15;//空间轴放大缩小倍数
            float firststation_y = 100;
            float last_station_y = 0;
            for (int station_index = 0; station_index < g.stationlist.Count() - 1; station_index++)
            {
                Station station = g.stationlist[station_index];
                Station stationnext = g.stationlist[station_index + 1];
                if (station_index == 0)
                {
                    stationnametoy.Add(station.name, firststation_y);                    
                    last_station_y = firststation_y;
                    stationnametoy.Add(stationnext.name, last_station_y + station.tonextstationdistance * stationzoom);
                    last_station_y = last_station_y + station.tonextstationdistance * stationzoom;
                }
                else
                {
                    stationnametoy.Add(stationnext.name, last_station_y + station.tonextstationdistance * stationzoom);
                    last_station_y = last_station_y + station.tonextstationdistance * stationzoom;
                }
            }
        }
        //时间在x轴上的投影
        float MapTimeToX(int time)
        {
            int begin_timehour = beginandendhour[0];
            float mapx=(time-begin_timehour*60)*timezoom/60+leftandrightx[0];
            return mapx;
        }
        //x轴的标尺，起点位置
        void XStander()
        {
            timezoom = 172;//时间轴放大/缩小倍数
            //timezoom = 120;
            int[] timespan = g.GetScheduleSpan();
            int begin_timehour = (int)Math.Round(Convert.ToDouble(timespan[0]) / 60);
            int end_timehour = (int)Math.Ceiling(Convert.ToDouble(timespan[1]) / 60);
            beginandendhour[0] = begin_timehour;
            beginandendhour[1] = end_timehour;
            leftandrightx[0] = 70;
            leftandrightx[1] = leftandrightx[0] + timezoom * (end_timehour - begin_timehour);
        }
    }
}
