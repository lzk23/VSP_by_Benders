﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ScheduleSys
{
    public class Test
    {
        static int[,] adjacent_matrix;
        static int[] vertice_cost;
        static void main()
        {

        }
        static void findshortestpath()
        {
            List<int> shourtest_path = new List<int>();
            int max_used_vertice = DataReadWrite.max_train_for_one_stock;
            int vertice_num = adjacent_matrix.GetLength(0);
            double[] current_distance = new double[vertice_num];//从源点到每个顶点的最短距离
            double[] pre_distance = new double[vertice_num];//前一阶段（指vertice_used-1）的最短距离
            int[,] pre_vertice = new int[max_used_vertice, vertice_num];
            //初始化
            for (int vertice = 0; vertice < vertice_num; vertice++)
            {
                current_distance[vertice] = vertice_cost[vertice];
                pre_distance[vertice] = current_distance[vertice];
                pre_vertice[0, vertice] = -1;
            }
            //限制最多可经过的顶点数量
            for (int vertice_used = 1; vertice_used <= max_used_vertice - 1; vertice_used++)
            {
                for (int vertice_1 = 0; vertice_1 < vertice_num; vertice_1++)
                {
                    for (int vertice_2 = 0; vertice_2 < vertice_num; vertice_2++)
                    {
                        double current_cost = adjacent_matrix[vertice_2, vertice_1] + pre_distance[vertice_2];
                        if (current_cost < current_distance[vertice_1])
                        {
                            current_distance[vertice_1] = current_cost;
                            pre_vertice[vertice_used, vertice_1] = vertice_2;
                        }
                    }
                    if (pre_distance[vertice_1] == current_distance[vertice_1])
                    {
                        pre_vertice[vertice_used, vertice_1] = pre_vertice[vertice_used - 1, vertice_1];
                    }
                }
                for (int vertice = 0; vertice < vertice_num; vertice++)
                {
                    pre_distance[vertice] = current_distance[vertice];
                }
            }
            double min_value = double.MaxValue;
            int min_vertice = -1;
            for (int vertice = 0; vertice < vertice_num; vertice++)
            {
                if (current_distance[vertice] < min_value)
                {
                    min_value = current_distance[vertice];
                    min_vertice = vertice;
                }
            }

            for (int vertice_used = max_used_vertice - 1; vertice_used >= 0; vertice_used--)
            {
                shourtest_path.Add(pre_vertice[vertice_used, min_vertice]);
                min_vertice = pre_vertice[vertice_used, min_vertice];
                if (min_vertice == -1)
                {
                    break;
                }
            }
        }
    }
}
